Aiming to build a text summarization tool in this repo using Python and a gui framework. Work in progress.
